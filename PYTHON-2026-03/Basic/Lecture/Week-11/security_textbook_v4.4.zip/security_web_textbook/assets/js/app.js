const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const terminalLines = [
  '$ boot security-class --safe-mode',
  '[OK] 공격 대상: 직접 만든 실습 페이지',
  '[OK] 학습 목표: 네트워크 원리 + 방어 습관',
  '[RULE] 타인 계정·기기·네트워크 테스트 금지',
  '[READY] Web textbook interface loaded',
  '',
  '오늘의 미션:',
  '1. 보안 5대 목표와 TCP/IP 계층 이해하기',
  '2. IP / DNS / Port / Packet / Protocol 이해하기',
  '3. 피싱과 가짜 Wi-Fi 위험 신호 찾기',
  '4. HTML/CSS/JS 속 flag를 찾으며 웹 구조 관찰하기',
  '5. 직접 코드를 실행하며 “브라우저에 온 정보” 확인하기',
  '',
  'Ready? start_lesson()'
];
const terminal = $('#typeTerminal');
let ti = 0, ci = 0;
function typeLoop(){
  if(!terminal || ti >= terminalLines.length) return;
  if(ci <= terminalLines[ti].length){
    terminal.textContent = terminalLines.slice(0,ti).join('\n') + (ti? '\n':'') + terminalLines[ti].slice(0,ci) + '█';
    ci++; setTimeout(typeLoop, 18);
  } else { ti++; ci=0; setTimeout(typeLoop, 120); }
}
typeLoop();

const modalData = {
  ip: ['IP 주소', 'IP 주소는 네트워크에서 장치를 찾기 위한 주소입니다. 집 주소가 있어야 택배가 도착하는 것처럼, 인터넷에서도 목적지 주소가 필요합니다. 학교나 집 공유기 안에서는 192.168.x.x 같은 사설 IP를 자주 볼 수 있습니다.', '예시\n내 컴퓨터: 192.168.0.24\n공유기: 192.168.0.1\n서버: 93.184.216.34'],
  dns: ['DNS', 'DNS는 사람이 기억하기 쉬운 이름을 컴퓨터가 사용하는 IP 주소로 바꿔주는 시스템입니다. 사용자가 example.com을 입력하면, 컴퓨터는 DNS에게 실제 주소를 물어봅니다.', 'example.com → 93.184.216.34\nnaver.com → 해당 서비스의 IP 주소'],
  port: ['포트', '한 컴퓨터 안에는 웹 서버, 게임 서버, 메신저 등 여러 프로그램이 동시에 실행될 수 있습니다. 포트는 그중 어떤 프로그램으로 데이터를 보낼지 정하는 문 번호입니다.', 'HTTP: 80\nHTTPS: 443\n개발용 서버: 3000, 5000, 8000 등'],
  http: ['HTTP', 'HTTP는 HyperText Transfer Protocol의 줄임말입니다. 웹 브라우저와 웹 서버가 HTML, CSS, 이미지 같은 웹 자료를 주고받기 위한 기본 약속입니다. 다만 HTTP 자체는 내용을 암호화하지 않기 때문에 로그인 정보나 개인정보를 보내기에는 안전하지 않습니다.', '비유: 봉투 없이 엽서를 보내는 느낌\n대표 포트: 80\n보안 관점: 로그인·결제·개인정보 입력에는 부적절'],
  https: ['HTTPS', 'HTTPS는 HTTP에 암호화 계층을 더한 방식입니다. 브라우저와 서버 사이의 내용을 중간에서 쉽게 읽거나 바꾸지 못하게 보호합니다. 하지만 HTTPS가 있다고 해서 그 사이트가 무조건 공식 사이트라는 뜻은 아닙니다.', '비유: 잠금장치가 있는 봉투로 보내는 느낌\n대표 포트: 443\n주의: 피싱 사이트도 HTTPS를 사용할 수 있음'],
  tcp: ['TCP', 'TCP는 Transmission Control Protocol의 줄임말입니다. 데이터를 보낼 때 빠진 조각이 없는지, 순서가 맞는지 확인하면서 안정적으로 전달하는 방식입니다. 웹페이지, 로그인, 파일 다운로드처럼 정확성이 중요한 통신에 많이 쓰입니다.', '비유: 택배를 보내고 송장번호로 도착 확인까지 하는 방식\n특징: 연결 지향, 순서 보장, 재전송'],
  udp: ['UDP', 'UDP는 User Datagram Protocol의 줄임말입니다. 도착 확인 절차를 줄여 빠르게 보내는 방식입니다. 일부 패킷이 빠져도 전체 흐름이 더 중요한 게임, 영상, 음성 통신에서 자주 사용됩니다.', '비유: 빠르게 공을 던지는 방식. 놓친 공을 하나하나 다시 확인하지 않음\n특징: 빠름, 가벼움, 순서/도착 보장 약함'],
  packet: ['패킷', '패킷은 데이터를 작게 나눈 조각입니다. 큰 사진이나 영상도 네트워크에서는 여러 패킷으로 나뉘어 이동하고, 도착 후 다시 합쳐집니다.', '패킷 안에는 보통 출발지, 목적지, 순서, 데이터 일부가 들어 있습니다.'],
  confidentiality: ['기밀성 Confidentiality', '허락받지 않은 사람이 정보를 몰래 보지 못하게 하는 성질입니다. 채팅 내용, 성적표, 계정 비밀번호는 기밀성이 중요합니다.', '깨진 예시: 친구가 내 비밀번호를 몰래 봄\n방어 예시: 암호화, 접근 권한, 화면 잠금'],
  integrity: ['무결성 Integrity', '데이터가 이동하거나 저장되는 중에 몰래 바뀌지 않았음을 보장하는 성질입니다. 송금 계좌번호, 시험 점수, 주문 금액이 바뀌면 큰 문제가 됩니다.', '깨진 예시: 결제 금액이 중간에 변경됨\n방어 예시: 해시, 전자서명, 서버 검증'],
  availability: ['가용성 Availability', '필요할 때 서비스를 정상적으로 사용할 수 있는 성질입니다. 학교 사이트, 게임 서버, 결제 시스템이 멈추면 가용성이 깨진 것입니다.', '깨진 예시: 접속자가 몰려 서버 마비\n방어 예시: 백업, 장애 대응, 트래픽 분산'],
  serverauth: ['서버 인증 Server Authentication', '내가 접속한 사이트가 진짜인지 확인하는 과정입니다. 가짜 로그인 페이지에 속지 않으려면 주소, 인증서, 공식 앱/사이트 확인이 중요합니다.', '질문: 이 사이트가 진짜 학교/은행/구글인가?\n관련: HTTPS 인증서, 도메인 확인'],
  clientauth: ['클라이언트 인증 Client Authentication', '접속한 사람이 진짜 사용자인지 확인하는 과정입니다. 아이디와 비밀번호만으로 부족할 수 있어 2단계 인증을 함께 사용합니다.', '질문: 로그인한 사람이 진짜 계정 주인인가?\n관련: 비밀번호, OTP, 생체인증, 보안키'],
  threat_phishing: ['피싱 Phishing', '진짜처럼 보이는 문자, 메일, 로그인 페이지로 사용자를 속여 계정 정보나 개인정보를 입력하게 만드는 공격입니다. 핵심은 기술보다 “믿게 만드는 연출”입니다.', '변종 용어\n- Smishing: 문자 메시지 피싱\n- Voice Phishing: 전화 피싱\n- Spear Phishing: 특정 사람이나 조직을 노리는 표적 피싱\n수업 포인트: 링크 주소, 긴급한 말투, 로그인 요구, 과한 보상을 함께 확인합니다.'],
  threat_malware: ['악성코드 Malware', 'Malware는 Malicious Software의 줄임말입니다. 사용자의 기기에서 몰래 실행되어 파일을 암호화하거나, 정보를 훔치거나, 원하지 않는 동작을 일으키는 프로그램을 말합니다.', '대표 유형\n- Ransomware: 파일을 잠그고 돈을 요구\n- Trojan Horse: 정상 프로그램처럼 속여 침투\n- Spyware: 몰래 정보를 관찰·수집\n수업 포인트: 모르는 첨부파일과 출처 불명 실행 파일은 열지 않습니다.'],
  threat_ato: ['계정 탈취 ATO', 'ATO는 Account Takeover의 줄임말입니다. 공격자가 다른 사람의 계정에 무단으로 로그인하거나 계정 권한을 빼앗는 상황을 뜻합니다.', '연관 용어\n- Credential Stuffing: 유출된 아이디/비밀번호 조합을 다른 사이트에 대입\n- Brute Force: 가능한 비밀번호를 반복 대입\n방어 포인트: 사이트마다 다른 비밀번호와 2단계 인증이 중요합니다.'],
  threat_social: ['사회공학 Social Engineering', '사회공학은 시스템의 버그보다 사람의 심리, 신뢰, 급한 상황을 이용하는 공격입니다. “기술 공격”처럼 보이지 않아도 매우 강력할 수 있습니다.', '연관 용어\n- Pretexting: 그럴듯한 시나리오를 만들어 속이기\n- Baiting: 선물, 무료 파일, 이벤트 같은 미끼 제공\n수업 포인트: 급할수록 멈추고 다른 경로로 확인합니다.'],
  term_smishing: ['스미싱 Smishing', 'SMS와 Phishing이 합쳐진 말입니다. 문자 메시지로 택배, 계정 정지, 결제 오류 같은 상황을 꾸며 링크 클릭이나 앱 설치를 유도합니다.', '위험 신호: 짧은 링크, APK 설치 요구, “오늘 안에 처리”, “계정 정지” 같은 압박 문구'],
  term_spear: ['스피어 피싱 Spear Phishing', '무작위로 뿌리는 피싱이 아니라 특정 학생, 선생님, 회사, 동아리처럼 대상을 정해 맞춤형으로 속이는 공격입니다.', '예시: “OO반 과제 파일입니다”처럼 실제 상황을 알고 있는 것처럼 꾸밈'],
  term_ransomware: ['랜섬웨어 Ransomware', '파일을 암호화해서 열 수 없게 만들고, 복구해주겠다며 돈을 요구하는 악성코드입니다. 중요한 파일 백업이 방어의 핵심입니다.', '방어: 백업, 업데이트, 출처 불명 파일 차단, 의심스러운 첨부파일 열지 않기'],
  term_trojan: ['트로이 목마 Trojan Horse', '겉으로는 게임, 유틸리티, 문서처럼 정상으로 보이지만 내부에 악성 기능을 숨긴 프로그램입니다.', '비유: 선물 상자처럼 보이지만 안에 위험한 기능이 숨어 있는 프로그램'],
  term_spyware: ['스파이웨어 Spyware', '사용자가 모르는 사이에 화면, 입력, 위치, 방문 기록 같은 정보를 몰래 관찰하거나 수집하는 악성 소프트웨어입니다.', '방어: 앱 권한 확인, 공식 스토어 사용, 수상한 확장 프로그램 제거'],
  term_credential: ['크리덴셜 스터핑 Credential Stuffing', '다른 사이트에서 유출된 아이디와 비밀번호 조합을 여러 서비스에 자동으로 대입해보는 공격 방식입니다.', '핵심 교훈: 같은 비밀번호를 여러 사이트에서 재사용하면 한 곳이 털렸을 때 다른 계정도 위험해집니다.'],
  term_bruteforce: ['브루트 포스 Brute Force', '가능한 비밀번호 조합을 계속 시도하는 무차별 대입 공격입니다. 짧고 단순한 비밀번호일수록 위험합니다.', '방어: 긴 비밀번호, 로그인 시도 제한, 2단계 인증, 비밀번호 관리자 사용'],
  term_pretexting: ['프리텍스팅 Pretexting', '공격자가 선생님, 친구, 관리자, 고객센터처럼 그럴듯한 역할과 상황을 만들어 신뢰를 얻는 방식입니다.', '예시: “계정 점검 중이라 인증번호가 필요해요”처럼 이유를 꾸며 민감정보를 요구'],
  term_baiting: ['베이팅 Baiting', '무료 쿠폰, 게임 아이템, 이벤트 파일, USB 같은 미끼를 제공해 클릭이나 실행을 유도하는 방식입니다.', '교훈: 공짜 보상일수록 출처와 목적을 확인해야 합니다.']
};
function openModal(key){
  const item = modalData[key];
  if(!item) return;
  $('#modalContent').innerHTML = `<h3>${item[0]}</h3><p>${item[1]}</p><code>${item[2]}</code>`;
  $('#modal').classList.add('open');
  $('#modal').setAttribute('aria-hidden','false');
}
function closeModal(){ $('#modal').classList.remove('open'); $('#modal').setAttribute('aria-hidden','true'); }
$$('[data-modal]').forEach(el => el.addEventListener('click', () => openModal(el.dataset.modal)));
$('#modalClose')?.addEventListener('click', closeModal);
$('#modal')?.addEventListener('click', e => { if(e.target.id === 'modal') closeModal(); });
addEventListener('keydown', e => { if(e.key === 'Escape') closeModal(); });

const conceptData = {
  ip: ['IP 주소', '인터넷에서 장치를 찾기 위한 주소입니다. 같은 네트워크 안에서 내 컴퓨터가 누구인지 알려주는 이름표 역할을 합니다.', '예: 192.168.0.24'],
  dns: ['DNS', '도메인 이름을 IP 주소로 바꿔줍니다. 사람이 naver.com을 기억하고, 컴퓨터는 IP 주소를 사용합니다.', '예: example.com → 93.184.216.34'],
  port: ['포트', '한 장치 안에서 어떤 프로그램 또는 서비스로 데이터를 보낼지 정하는 번호입니다.', '예: HTTPS는 보통 443번 포트'],
  packet: ['패킷', '데이터를 작게 나눈 조각입니다. 큰 파일도 여러 패킷으로 나뉘어 이동합니다.', '예: 사진 한 장 → 여러 패킷'],
  protocol: ['프로토콜', '네트워크에서 데이터를 주고받기 위한 약속입니다. 서로 같은 규칙을 사용해야 통신할 수 있습니다.', '예: HTTP, HTTPS, TCP, UDP, DNS'],
  http: ['HTTP', '웹 브라우저와 서버가 웹페이지를 주고받는 약속입니다. 암호화가 기본으로 들어 있지 않아 중요한 정보를 보내기에는 위험합니다.', '예: http://example.com'],
  https: ['HTTPS', 'HTTP 통신에 암호화를 더한 방식입니다. 중간에서 내용을 훔쳐보거나 바꾸기 어렵게 만듭니다.', '예: https://accounts.google.com'],
  tcp: ['TCP', '데이터가 빠지지 않고 순서대로 도착했는지 확인하는 안정성 중심의 전송 방식입니다.', '예: 웹 접속, 파일 다운로드, 로그인'],
  udp: ['UDP', '확인 절차를 줄여 빠르게 보내는 속도 중심의 전송 방식입니다.', '예: 실시간 게임, 영상 스트리밍, 음성 통화']
};
function renderConcept(key){
  const v = conceptData[key];
  const view = $('#conceptView');
  if(view) view.innerHTML = `<h3>${v[0]}</h3><p>${v[1]}</p><code>${v[2]}</code>`;
}
renderConcept('ip');
$$('.concept').forEach(btn=>btn.addEventListener('click',()=>{
  $$('.concept').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); renderConcept(btn.dataset.concept);
}));

const ethicsItems = [
  ['친구의 허락 없이 계정 비밀번호를 추측해본다.', false, '허락 없는 계정 접근 시도는 장난이어도 문제가 됩니다.'],
  ['내가 만든 HTML 실습 페이지에서 숨겨진 flag를 찾는다.', true, '직접 만든 안전한 실습장 안에서 원리를 관찰하는 것은 좋은 활동입니다.'],
  ['학교가 허락한 범위에서 보안 점검 체크리스트를 작성한다.', true, '허락받은 범위와 목적이 명확하면 방어 활동이 됩니다.'],
  ['무료 Wi-Fi를 만들어 친구에게 로그인하게 유도한다.', false, '계정 정보를 입력하게 속이는 행위는 피싱과 연결될 수 있습니다.']
];
const ethicsCards = $('#ethicsCards');
if(ethicsCards){
  ethicsItems.forEach(([text, safe, feedback])=>{
    const card = document.createElement('article');
    card.className = 'judge-card';
    card.innerHTML = `<h3>${safe ? '판단해보기' : '판단해보기'}</h3><p>${text}</p><small>클릭해서 확인</small>`;
    card.onclick = () => {
      card.classList.add(safe ? 'correct' : 'wrong');
      card.innerHTML = `<h3>${safe ? '안전한 활동' : '위험한 활동'}</h3><p>${text}</p><b>${feedback}</b>`;
    };
    ethicsCards.appendChild(card);
  });
}

const cmdData = {
  ipconfig: `C:\\Users\\Student> ipconfig\n\n무선 LAN 어댑터 Wi-Fi:\n   IPv4 주소 . . . . . . . . . : 192.168.0.24\n   서브넷 마스크 . . . . . . . : 255.255.255.0\n   기본 게이트웨이 . . . . . . : 192.168.0.1\n   DNS 서버 . . . . . . . . . : 8.8.8.8\n\n해석:\n- IPv4 주소는 내 컴퓨터의 네트워크 주소입니다.\n- 기본 게이트웨이는 보통 공유기 주소입니다.\n- DNS 서버는 도메인 이름을 IP 주소로 바꿔줍니다.`,
  ping: `C:\\Users\\Student> ping example.com\n\n93.184.216.34의 응답: 바이트=32 시간=28ms TTL=56\n93.184.216.34의 응답: 바이트=32 시간=27ms TTL=56\n\n해석:\n- 서버와 통신이 가능한지 확인합니다.\n- 시간(ms)은 왕복 응답 시간입니다.\n- 응답이 없다고 해서 항상 공격당한 것은 아닙니다. 방화벽이나 서버 설정 때문일 수도 있습니다.`,
  nslookup: `C:\\Users\\Student> nslookup example.com\n\n서버:  dns.google\nAddress: 8.8.8.8\n\n이름: example.com\nAddress: 93.184.216.34\n\n해석:\n- 도메인 이름이 어떤 IP 주소와 연결되는지 확인합니다.\n- DNS는 인터넷의 전화번호부처럼 동작합니다.`,
  tracert: `C:\\Users\\Student> tracert example.com\n\n  1    2 ms    1 ms    1 ms  192.168.0.1\n  2   10 ms    9 ms   10 ms  ISP-Gateway\n  3   28 ms   27 ms   28 ms  example.com\n\n해석:\n- 목적지까지 가는 중간 경로를 관찰합니다.\n- 실제 수업에서는 외부 서비스에 반복 실행하지 않고 예시 중심으로 설명합니다.`
};
function renderCmd(key){ const out = $('#cmdOutput'); if(out) out.textContent = cmdData[key]; }
renderCmd('ipconfig');
$$('.cmd-tab').forEach(btn=>btn.addEventListener('click',()=>{
  $$('.cmd-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); renderCmd(btn.dataset.cmd);
}));

const riskOptions = [
  ['긴급하게 행동하라고 압박한다', true],
  ['공식 주소처럼 보이지 않는 링크를 사용한다', true],
  ['10분 안에 로그인하라고 한다', true],
  ['학교 계정이라는 단어가 들어가니 무조건 안전하다', false],
  ['http 링크라서 더 주의가 필요하다', true]
];
const riskChecks = $('#riskChecks');
if(riskChecks){
  riskOptions.forEach(([text])=>{
    const label = document.createElement('label');
    label.innerHTML = `<input type="checkbox"> ${text}`;
    riskChecks.appendChild(label);
  });
  const btn = document.createElement('button');
  btn.textContent = '위험 신호 확인';
  btn.className = 'primary-btn';
  btn.onclick = () => {
    let score = 0;
    $$('label', riskChecks).forEach((label, idx)=>{
      const checked = $('input', label).checked;
      const ok = checked === riskOptions[idx][1];
      label.style.borderColor = ok ? 'var(--green)' : 'var(--red)';
      if(ok) score++;
    });
    $('#riskResult').textContent = `판별 점수: ${score}/${riskOptions.length} — 핵심은 긴급함, 로그인 요구, 이상한 주소, 너무 좋은 조건을 의심하는 것입니다.`;
  };
  riskChecks.after(btn);
}

const wifi = [
  ['School_Official_WiFi','확인 필요','공식처럼 보이지만 이름은 누구나 따라 만들 수 있습니다. 학교가 안내한 정확한 이름인지 확인해야 합니다.'],
  ['School_Free_WiFi_Login','위험 신호 큼','Free와 Login 조합은 계정 입력을 유도하는 가짜 로그인 페이지와 연결될 수 있습니다.'],
  ['Free_5G_Unlimited','위험 신호 큼','무료, 무제한, 빠른 인터넷처럼 너무 좋은 조건은 접속을 유도하는 미끼일 수 있습니다.'],
  ['Cafe_WiFi','확인 필요','평범해 보이지만 직원에게 실제 Wi-Fi 이름인지 확인하는 것이 안전합니다.'],
  ['Cafe_WiFi_2','주의','진짜와 비슷한 이름으로 속이는 Evil Twin 방식일 수 있습니다. 비슷한 이름이 여러 개면 확인이 필요합니다.']
];
const wifiList = $('#wifiList');
if(wifiList){
  wifi.forEach((w,i)=>{
    const el = document.createElement('div'); el.className='wifi-item';
    el.innerHTML = `<strong>${i+1}. ${w[0]}</strong><span>${w[1]}</span>`;
    el.onclick=()=>{ $$('.wifi-item').forEach(x=>x.classList.remove('active')); el.classList.add('active'); $('#wifiResult').innerHTML=`<h3>${w[0]}</h3><b>${w[1]}</b><p>${w[2]}</p><div class="rule-box"><strong>핵심</strong><p>Wi-Fi 이름은 신분증이 아닙니다. 출처 확인이 먼저입니다.</p></div>`; };
    wifiList.appendChild(el);
  });
}



const ciaScenarios = [
  ['친구가 내 메신저 내용을 몰래 읽었다.', '기밀성', '내용이 허락 없이 노출되었으므로 기밀성 문제입니다.'],
  ['온라인 주문 중 배송 주소가 중간에 다른 주소로 바뀌었다.', '무결성', '데이터가 변조되었으므로 무결성 문제입니다.'],
  ['학교 홈페이지가 하루 종일 접속되지 않았다.', '가용성', '필요할 때 서비스를 사용할 수 없으므로 가용성 문제입니다.'],
  ['가짜 은행 사이트에 접속해서 로그인했다.', '서버 인증', '진짜 서버인지 확인하지 못한 문제입니다.'],
  ['누군가 내 비밀번호로 게임 계정에 로그인했다.', '클라이언트 인증', '접속자가 진짜 사용자인지 확인하지 못한 문제입니다.']
];
let ciaIndex = 0;
function renderCia(){
  const scenario = $('#ciaScenario'), choices = $('#ciaChoices'), result = $('#ciaResult');
  if(!scenario || !choices) return;
  const [text, answer] = ciaScenarios[ciaIndex];
  scenario.textContent = text;
  choices.innerHTML = '';
  if(result) result.textContent = '';
  ['기밀성','무결성','가용성','서버 인증','클라이언트 인증'].forEach(choice=>{
    const btn = document.createElement('button');
    btn.textContent = choice;
    btn.onclick = () => {
      $$('#ciaChoices button').forEach(b=>b.disabled=true);
      const ok = choice === answer;
      btn.classList.add(ok ? 'correct' : 'wrong');
      if(!ok){
        const correct = [...$$('#ciaChoices button')].find(b=>b.textContent === answer);
        correct?.classList.add('correct');
      }
      if(result) result.textContent = `${ok ? '정답!' : '아깝습니다.'} ${ciaScenarios[ciaIndex][2]}`;
    };
    choices.appendChild(btn);
  });
}
$('#nextCia')?.addEventListener('click',()=>{ ciaIndex = (ciaIndex + 1) % ciaScenarios.length; renderCia(); });
renderCia();

const layerInfo = {
  app: ['응용 계층', '사용자가 직접 만나는 서비스 계층입니다. 웹 브라우저, 메신저, 게임 클라이언트가 여기에 가깝습니다.', '예: HTTP, HTTPS, DNS, SMTP'],
  transport: ['전송 계층', '데이터를 나누고 순서, 포트, 도착 확인을 관리합니다. TCP는 안정성, UDP는 속도를 중시합니다.', '예: TCP 443 → HTTPS 서버로 전달\n예: UDP → 실시간 게임/영상/음성'],
  internet: ['인터넷 계층', 'IP 주소를 보고 목적지까지 경로를 찾습니다. 여러 네트워크를 지나 목적지로 가는 길잡이 역할입니다.', '예: 출발지 IP 192.168.0.24\n목적지 IP 93.184.216.34'],
  access: ['네트워크 접근 계층', 'Wi-Fi, 랜선 같은 실제 통신 매체를 통해 신호를 보냅니다. 가까운 네트워크 안에서 장치를 구분합니다.', '예: Wi-Fi, Ethernet, MAC 주소']
};
$$('[data-layer]').forEach(card=>card.addEventListener('click',()=>{
  $$('[data-layer]').forEach(c=>c.classList.remove('active'));
  card.classList.add('active');
  const info = layerInfo[card.dataset.layer];
  const box = $('#layerDetail');
  if(box) box.innerHTML = `<h3>${info[0]}</h3><p>${info[1]}</p><code>${info[2]}</code>`;
}));

const snippets = {
  comment: `<!DOCTYPE html>\n<html lang="ko">\n<body>\n  <h1>HTML 주석 실험</h1>\n  <p>화면에는 flag가 보이지 않습니다.</p>\n\n  <!-- FLAG{comment_is_visible_in_source} -->\n</body>\n</html>`,
  css: `<!DOCTYPE html>\n<html lang="ko">\n<head>\n  <style>\n    .secret { display: none; }\n  </style>\n</head>\n<body>\n  <h1>CSS 숨김 실험</h1>\n  <p>CSS는 정보를 삭제하지 않고 화면에서 숨길 수 있습니다.</p>\n  <p class="secret">FLAG{css_hidden_is_still_html}</p>\n</body>\n</html>`,
  js: `<!DOCTYPE html>\n<html lang="ko">\n<body>\n  <h1>JavaScript 버튼 실험</h1>\n  <button onclick="showFlag()">버튼 클릭</button>\n  <p id="result"></p>\n  <script>\n    const flag = "FLAG{javascript_runs_in_browser}";\n    function showFlag(){\n      document.getElementById('result').innerText = flag;\n    }\n  <\/script>\n</body>\n</html>`,
  base64: `<!DOCTYPE html>\n<html lang="ko">\n<body>\n  <h1>Base64 실험</h1>\n  <p>아래 문자열은 암호화가 아니라 인코딩입니다.</p>\n  <code id="encoded">RkxBR3tiYXNlNjRfaXNfbm90X2VuY3J5cHRpb259</code>\n  <button onclick="decode()">디코딩</button>\n  <p id="result"></p>\n  <script>\n    function decode(){\n      const text = document.getElementById('encoded').innerText;\n      document.getElementById('result').innerText = atob(text);\n    }\n  <\/script>\n</body>\n</html>`
};
const editor = $('#codeEditor');
const frame = $('#previewFrame');
let currentSnippet = 'comment';
function setSnippet(key){
  currentSnippet = key;
  if(editor) editor.value = snippets[key];
  $$('.snippet-btn').forEach(b => b.classList.toggle('active', b.dataset.snippet === key));
  runCode();
}
function runCode(){
  if(!editor || !frame) return;
  frame.srcdoc = editor.value;
}
$$('.snippet-btn').forEach(btn => btn.addEventListener('click', () => setSnippet(btn.dataset.snippet)));
$('#runCode')?.addEventListener('click', runCode);
$('#resetCode')?.addEventListener('click', () => setSnippet(currentSnippet));
setSnippet('comment');

const pwInput = $('#pwInput');
if(pwInput){
  pwInput.addEventListener('input',()=>{
    const v = pwInput.value; let score = 0;
    if(v.length>=8) score++; if(v.length>=12) score++; if(/[A-Z]/.test(v)&&/[a-z]/.test(v)) score++; if(/[0-9]/.test(v)) score++; if(/[^A-Za-z0-9]/.test(v)) score++;
    const pct = [0,20,40,65,82,100][score]; const bar = $('#strengthBar');
    bar.style.width = pct+'%'; bar.style.background = score<2?'var(--red)':score<4?'var(--yellow)':'var(--green)';
    $('#strengthText').textContent = score<2?'너무 약합니다. 길이를 늘리고 예측하기 어렵게 만드세요.':score<4?'괜찮지만 더 길게 만들면 좋습니다.':'좋습니다. 실제로는 사이트마다 다르게 사용하고 2단계 인증을 켜세요.';
  });
}

const quiz = [
  {
    q:'해킹 수업에서 가장 중요한 기준은?',
    options:['빠르게 뚫기','허락과 책임','도구 많이 쓰기'], answer:1,
    why:'보안 수업의 핵심은 허락받은 범위에서 책임 있게 원리를 이해하고 방어하는 것입니다.',
    wrong:['빠르게 뚫는 속도는 수업 목표가 아닙니다. 허락 없는 시도는 공격이 될 수 있습니다.','정답입니다. 허락, 범위, 책임이 보안 활동과 공격을 나누는 기준입니다.','도구를 많이 아는 것보다 언제 멈춰야 하는지 아는 것이 더 중요합니다.']
  },
  {
    q:'DNS의 역할은?',
    options:['도메인을 IP 주소로 바꾸기','비밀번호 저장하기','컴퓨터 전원 켜기'], answer:0,
    why:'DNS는 naver.com 같은 이름을 컴퓨터가 찾아갈 수 있는 IP 주소로 바꿔주는 시스템입니다.',
    wrong:['정답입니다. DNS는 인터넷의 이름표 번역기입니다.','비밀번호 저장은 인증 시스템이나 비밀번호 관리자와 관련된 주제입니다.','컴퓨터 전원과 DNS는 직접적인 관련이 없습니다.']
  },
  {
    q:'Base64에 대한 설명으로 맞는 것은?',
    options:['강력한 암호화다','인코딩이라 되돌릴 수 있다','바이러스를 막는다'], answer:1,
    why:'Base64는 데이터를 다른 문자 표현으로 바꾸는 인코딩입니다. 비밀을 안전하게 숨기는 암호화가 아닙니다.',
    wrong:['Base64는 암호화가 아닙니다. 누구나 쉽게 디코딩할 수 있습니다.','정답입니다. Base64는 되돌릴 수 있는 표현 방식입니다.','Base64는 악성코드나 바이러스를 막는 보안 기능이 아닙니다.']
  },
  {
    q:'가짜 Wi-Fi를 조심해야 하는 이유는?',
    options:['이름을 누구나 비슷하게 만들 수 있어서','항상 속도가 느려서','무조건 유료라서'], answer:0,
    why:'Wi-Fi 이름은 신분증이 아닙니다. 공격자가 공식 이름과 비슷하게 만들어 접속을 유도할 수 있습니다.',
    wrong:['정답입니다. School_Official_WiFi처럼 보여도 실제 운영자가 누구인지 확인해야 합니다.','속도는 위험 판단의 핵심 기준이 아닙니다. 빠른 가짜 Wi-Fi도 있을 수 있습니다.','무료/유료 여부보다 출처와 운영자를 확인하는 것이 중요합니다.']
  },
  {
    q:'브라우저에 전달된 HTML 주석은?',
    options:['사용자가 볼 수 있다','완전히 삭제된다','서버 관리자만 볼 수 있다'], answer:0,
    why:'HTML 주석은 화면에 보이지 않을 뿐, 브라우저에 전달되면 개발자 도구나 소스 보기로 확인될 수 있습니다.',
    wrong:['정답입니다. 그래서 주석에 비밀번호나 secret을 넣으면 안 됩니다.','브라우저에 전달된 주석은 자동으로 완전히 삭제되지 않습니다.','서버 관리자만 보는 정보가 아니라 사용자 브라우저에도 전달될 수 있습니다.']
  },
  {
    q:'중요한 로그인 검증은 어디에서 해야 안전한가?',
    options:['브라우저만','HTML 주석','서버'], answer:2,
    why:'브라우저의 코드는 사용자가 볼 수 있고 조작할 수 있습니다. 중요한 검증은 서버에서 해야 합니다.',
    wrong:['브라우저 검증은 편의용으로는 가능하지만 보안의 최종 기준이 되면 위험합니다.','HTML 주석은 보안 검증 장소가 아니라 사용자가 볼 수 있는 코드 일부입니다.','정답입니다. 서버에서 계정, 비밀번호, 권한을 검증해야 안전합니다.']
  },
  {
    q:'HTTPS가 중요한 이유는?',
    options:['항상 무료라서','통신 내용을 암호화하기 위해서','컴퓨터 속도를 무조건 높여서'], answer:1,
    why:'HTTPS는 브라우저와 서버 사이의 통신을 암호화해 중간에서 내용을 훔쳐보거나 바꾸기 어렵게 합니다.',
    wrong:['무료 여부는 HTTPS의 핵심 이유가 아닙니다.','정답입니다. HTTPS는 통신 암호화가 핵심입니다. 다만 공식 사이트 보증은 아닙니다.','HTTPS가 컴퓨터 속도를 무조건 높여주는 기능은 아닙니다.']
  },
  {
    q:'친구가 내 메시지를 몰래 본 상황은 어떤 보안 목표 문제인가?',
    options:['기밀성','가용성','포트 번호'], answer:0,
    why:'허락받지 않은 사람이 정보를 본 것이므로 기밀성 문제가 발생한 것입니다.',
    wrong:['정답입니다. 기밀성은 몰래 보면 안 되는 정보를 보호하는 목표입니다.','가용성은 서비스가 필요할 때 정상적으로 사용 가능한지와 관련됩니다.','포트 번호는 서비스의 문 번호이지 보안 목표가 아닙니다.']
  },
  {
    q:'데이터가 중간에 바뀌지 않아야 한다는 목표는?',
    options:['무결성','DNS','UDP'], answer:0,
    why:'무결성은 데이터가 저장되거나 이동하는 동안 허락 없이 바뀌지 않았음을 보장하는 목표입니다.',
    wrong:['정답입니다. 송금 계좌번호나 시험 점수가 바뀌면 무결성이 깨진 것입니다.','DNS는 도메인 이름을 IP 주소로 바꾸는 시스템입니다.','UDP는 전송 프로토콜이며 보안 목표 이름이 아닙니다.']
  },
  {
    q:'TCP/IP 4계층 중 IP 주소로 길을 찾는 계층은?',
    options:['응용 계층','인터넷 계층','네트워크 접근 계층'], answer:1,
    why:'인터넷 계층은 IP 주소를 사용해 목적지까지의 경로를 찾는 역할을 합니다.',
    wrong:['응용 계층은 브라우저, HTTP, DNS처럼 사용자가 만나는 서비스와 가깝습니다.','정답입니다. IP 주소 기반 길찾기는 인터넷 계층의 핵심입니다.','네트워크 접근 계층은 실제 Wi-Fi, 랜선, MAC 주소 같은 가까운 전송과 관련됩니다.']
  },
  {
    q:'TCP와 UDP를 비교한 설명으로 맞는 것은?',
    options:['TCP는 안정성, UDP는 속도에 더 초점을 둔다','UDP는 항상 TCP보다 안전하다','TCP는 웹에서 절대 사용되지 않는다'], answer:0,
    why:'TCP는 순서와 재전송 등 안정성을 중시하고, UDP는 확인 절차를 줄여 빠른 전달을 중시합니다.',
    wrong:['정답입니다. 정확히 도착해야 하는 웹/파일 전송은 TCP와 잘 맞고, 실시간 게임/음성은 UDP와 잘 맞는 경우가 많습니다.','UDP가 항상 더 안전한 것은 아닙니다. 보안은 암호화, 인증, 설계와 함께 봐야 합니다.','웹 통신은 TCP 위에서 동작하는 경우가 많습니다. HTTPS도 보통 TCP 443번 포트를 사용합니다.']
  },
  {
    q:'HTTP와 HTTPS의 차이로 가장 알맞은 것은?',
    options:['HTTPS는 통신 암호화가 추가된다','HTTP는 무조건 피싱이고 HTTPS는 무조건 공식 사이트다','HTTPS는 DNS를 사용하지 않는다'], answer:0,
    why:'HTTPS는 HTTP에 암호화와 인증서 기반 보호가 더해진 방식입니다. 하지만 피싱 사이트도 HTTPS를 쓸 수 있습니다.',
    wrong:['정답입니다. HTTPS는 통신 내용을 보호하는 데 중요합니다.','HTTP/HTTPS만으로 피싱 여부가 결정되지는 않습니다. 중심 도메인을 함께 확인해야 합니다.','HTTPS 사이트도 접속 전에 DNS 조회를 사용할 수 있습니다.']
  }
];

quiz.push(
  {
    q:'쿠키와 세션에 대한 설명으로 가장 알맞은 것은?',
    options:['쿠키는 브라우저에 저장될 수 있고, 세션은 서버가 로그인 상태를 기억하는 데 쓰인다','쿠키는 무조건 바이러스다','세션 ID는 친구에게 공유해도 안전하다'], answer:0,
    why:'쿠키는 브라우저에 저장되는 작은 정보이고, 세션은 서버가 사용자의 로그인 상태를 기억하는 데 사용됩니다. 세션 ID는 임시 출입증처럼 조심해야 합니다.',
    wrong:['정답입니다. 쿠키와 세션은 로그인 상태 유지에 자주 함께 사용됩니다.','쿠키 자체가 무조건 악성은 아닙니다. 다만 민감 정보 저장 방식이 잘못되면 위험할 수 있습니다.','세션 ID가 노출되면 로그인 상태를 빼앗길 수 있어 공유하면 안 됩니다.']
  },
  {
    q:'2단계 인증의 핵심 효과는?',
    options:['비밀번호가 유출되어도 추가 확인으로 한 번 더 막을 수 있다','비밀번호를 아예 만들지 않아도 된다','피싱 사이트가 절대 생기지 않게 한다'], answer:0,
    why:'2단계 인증은 비밀번호 외에 OTP, 휴대폰 승인, 보안키 같은 추가 증거를 요구해 계정 탈취를 어렵게 만듭니다.',
    wrong:['정답입니다. 비밀번호 하나에만 의존하지 않는 것이 핵심입니다.','2단계 인증을 사용해도 기본 비밀번호는 여전히 필요합니다.','2단계 인증은 피싱 사이트 존재 자체를 없애지는 못합니다. 다만 피해 가능성을 줄일 수 있습니다.']
  },
  {
    q:'앱 권한을 허용할 때 가장 좋은 기준은?',
    options:['앱 기능에 꼭 필요한 권한인지 확인한다','무료 앱이면 모든 권한을 허용한다','권한 요청은 전부 무조건 거부한다'], answer:0,
    why:'앱 권한은 기능에 필요한 만큼만 허용하는 최소 권한 원칙이 중요합니다.',
    wrong:['정답입니다. 계산기 앱이 위치나 마이크를 요구한다면 의심해야 합니다.','무료 여부는 권한 허용 기준이 아닙니다.','모든 권한을 무조건 거부하면 정상 기능도 사용할 수 없을 수 있습니다. 필요한 권한만 허용하는 것이 핵심입니다.']
  }
);

const quizBox = $('#quizBox');
function renderQuiz(){
  if(!quizBox) return;
  quizBox.innerHTML=''; $('#quizResult').textContent='';
  quiz.forEach((q,idx)=>{
    const div=document.createElement('div'); div.className='question';
    div.innerHTML=`<h3>Q${idx+1}. ${q.q}</h3>`+q.options.map((a,i)=>`<label><input type="radio" name="q${idx}" value="${i}"> ${a}</label>`).join('')+`<div class="quiz-explain" id="explain${idx}"></div>`;
    quizBox.appendChild(div);
  });
}
renderQuiz();
$('#checkQuiz')?.addEventListener('click',()=>{
  let score=0;
  quiz.forEach((q,idx)=>{
    const checked=$(`input[name=q${idx}]:checked`);
    const picked=checked ? Number(checked.value) : -1;
    if(picked===q.answer) score++;
    const box=$(`#explain${idx}`);
    if(box){
      const pickedText = picked>=0 ? q.options[picked] : '선택 안 함';
      box.className = 'quiz-explain show ' + (picked===q.answer ? 'correct' : 'wrong');
      box.innerHTML = `<strong>${picked===q.answer?'정답':'다시 확인'}</strong><p><b>내 선택:</b> ${pickedText}</p><p><b>정답:</b> ${q.options[q.answer]}</p><p>${q.why}</p><details><summary>선택지 해설 보기</summary>${q.options.map((opt,i)=>`<p><b>${i+1}. ${opt}</b><br>${q.wrong[i]}</p>`).join('')}</details>`;
    }
  });
  $('#quizResult').textContent = `점수: ${score}/${quiz.length}  ${score===quiz.length?'완벽합니다!':'아래 해설을 보고 다시 정리해보세요.'}`;
});
$('#resetQuiz')?.addEventListener('click', renderQuiz);

const sections = $$('section[id]');
const links = $$('.nav-link');
function onScroll(){
  const max = document.documentElement.scrollHeight - innerHeight;
  const pct = max > 0 ? Math.max(0, Math.min(100, Math.round(scrollY / max * 100))) : 0;
  const bar = $('#progressBar'), text = $('#progressText');
  if(bar) bar.style.width=pct+'%'; if(text) text.textContent=pct+'%';
  $('#toTop')?.classList.toggle('show', scrollY>600);
  let current = sections[0]?.id;
  sections.forEach(s=>{ if(scrollY >= s.offsetTop-150) current=s.id; });
  links.forEach(a=>a.classList.toggle('active', a.getAttribute('href')==='#'+current));
}
addEventListener('scroll',onScroll); onScroll();
$('#toTop')?.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));
$('#themeBtn')?.addEventListener('click',()=>document.documentElement.classList.toggle('light'));
function toggleFocus(force){
  const on = typeof force === 'boolean' ? force : !document.body.classList.contains('focus');
  document.body.classList.toggle('focus', on);
  const btn = $('#focusModeBtn');
  if(btn) btn.textContent = on ? '집중 모드 종료' : '집중 모드';
}
$('#focusModeBtn')?.addEventListener('click',()=>toggleFocus());
$('#exitFocusBtn')?.addEventListener('click',()=>toggleFocus(false));

/* ===== Pro Plus v2: selectable term popover + polished command explanations ===== */
const commandMeta = {
  ipconfig: {
    title: 'ipconfig — 내 컴퓨터의 네트워크 신분증 확인',
    story: 'ipconfig는 Internet Protocol Configuration의 줄임말입니다. “지금 내 컴퓨터가 어떤 네트워크 주소표를 달고 있는지” 확인하는 관찰 명령어입니다. IPv4 주소, 서브넷 마스크, 기본 게이트웨이, DNS 서버를 보면 내 컴퓨터가 어느 네트워크 안에 있고, 바깥 인터넷으로 나갈 때 어디를 거치는지 알 수 있습니다.',
    output: `C:\\Users\\Student> ipconfig\n\n무선 LAN 어댑터 Wi-Fi:\n   IPv4 주소 . . . . . . . . . : 192.168.0.24\n   서브넷 마스크 . . . . . . . : 255.255.255.0\n   기본 게이트웨이 . . . . . . : 192.168.0.1\n   DNS 서버 . . . . . . . . . : 8.8.8.8\n\n읽는 법:\n- IPv4 주소: 우리 교실 네트워크 안에서 내 컴퓨터의 주소\n- 기본 게이트웨이: 인터넷으로 나가는 첫 번째 문, 보통 공유기\n- DNS 서버: naver.com 같은 이름을 IP 주소로 번역해주는 안내소\n\n수업 포인트:\n공격용 명령어가 아니라, 내 컴퓨터가 네트워크에 어떻게 연결되어 있는지 확인하는 진단 도구입니다.`
  },
  ping: {
    title: 'ping — 목적지까지 “살아 있나요?”라고 두드려보기',
    story: 'ping은 작은 패킷을 목적지로 보내고, 답장이 돌아오는지 확인하는 명령어입니다. 돌아오는 데 걸린 시간은 ms 단위로 표시됩니다. 잠수함이 음파를 쏘아 물체를 감지하는 “핑”과 비슷하게, 네트워크에서도 작은 신호로 연결 상태를 확인한다고 생각하면 됩니다.',
    output: `C:\\Users\\Student> ping example.com\n\n93.184.216.34의 응답: 바이트=32 시간=28ms TTL=56\n93.184.216.34의 응답: 바이트=32 시간=27ms TTL=56\n93.184.216.34의 응답: 바이트=32 시간=29ms TTL=56\n\n읽는 법:\n- 시간=28ms: 내 컴퓨터에서 서버까지 갔다가 돌아온 왕복 시간\n- 바이트=32: 보낸 테스트 패킷의 크기\n- TTL: 패킷이 네트워크에서 무한히 떠돌지 않도록 제한하는 수명\n\n주의:\n응답이 없다고 해서 무조건 서버가 꺼진 것은 아닙니다. 방화벽이나 서버 정책 때문에 ping을 막아둘 수도 있습니다.`
  },
  nslookup: {
    title: 'nslookup — DNS에게 “이 이름의 실제 주소가 뭐야?” 묻기',
    story: 'nslookup은 Name Server Lookup의 줄임말입니다. 사람이 기억하는 도메인 이름과 컴퓨터가 사용하는 IP 주소 사이의 연결을 확인합니다. 웹 브라우저가 사이트에 접속하기 전, 뒤에서는 이런 이름표 번역 과정이 먼저 일어납니다.',
    output: `C:\\Users\\Student> nslookup example.com\n\n서버:  dns.google\nAddress: 8.8.8.8\n\n이름: example.com\nAddress: 93.184.216.34\n\n읽는 법:\n- dns.google / 8.8.8.8: 질문을 받은 DNS 서버\n- example.com: 사람이 기억하기 쉬운 도메인 이름\n- 93.184.216.34: 컴퓨터가 실제로 찾아가는 IP 주소\n\n수업 포인트:\nDNS는 인터넷의 전화번호부처럼 보이지만, 보안에서는 “가짜 주소로 속이지 않는가?”를 확인하는 중요한 출발점이기도 합니다.`
  },
  tracert: {
    title: 'tracert — 패킷의 여행 경로를 따라가기',
    story: 'tracert는 Trace Route의 줄임말입니다. 내 컴퓨터에서 목적지 서버까지 한 번에 순간이동하는 것이 아니라, 여러 라우터를 거쳐 이동합니다. tracert는 그 중간 경로를 한 줄씩 보여주며, 각 구간에서 얼마나 시간이 걸리는지 관찰하게 해줍니다. macOS와 Linux에서는 traceroute라는 이름으로 사용됩니다.',
    output: `C:\\Users\\Student> tracert example.com\n\n  1    2 ms    1 ms    1 ms  192.168.0.1\n  2   10 ms    9 ms   10 ms  ISP-Gateway\n  3   21 ms   22 ms   21 ms  transit-router\n  4   28 ms   27 ms   28 ms  example.com\n\n읽는 법:\n- 1, 2, 3, 4: 목적지까지 지나간 단계, 즉 홉\n- ms: 각 단계까지의 응답 시간\n- 첫 번째 줄은 보통 우리 집/학교 공유기일 가능성이 큽니다.\n\n주의:\n수업에서는 예시 중심으로 다루고, 외부 서버에 반복적으로 실행하지 않습니다.`
  }
};
Object.keys(commandMeta).forEach(k => { if (typeof cmdData !== 'undefined') cmdData[k] = commandMeta[k].output; });
function renderCmdStory(key){
  const box = $('#cmdStory');
  if(!box || !commandMeta[key]) return;
  box.innerHTML = `<h3>${commandMeta[key].title}</h3><p>${commandMeta[key].story}</p>`;
}
renderCmdStory('ipconfig');
$$('.cmd-tab').forEach(btn => btn.addEventListener('click', () => renderCmdStory(btn.dataset.cmd)));
renderCmd('ipconfig');

const termData = {
  'ipconfig': {
    title: 'ipconfig',
    subtitle: 'Internet Protocol Configuration',
    short: '내 컴퓨터의 IP 주소, 게이트웨이, DNS 서버처럼 “현재 네트워크 연결 정보”를 확인하는 명령어입니다.',
    long: 'ipconfig는 Windows에서 네트워크 상태를 확인할 때 가장 먼저 보는 명령어입니다. 여기서 IPv4 주소는 내 컴퓨터의 교실 좌석 번호, 기본 게이트웨이는 교실 밖 인터넷으로 나가는 문, DNS 서버는 사이트 이름을 실제 주소로 바꿔주는 안내 데스크라고 볼 수 있습니다. IP를 새로 받거나 DNS 캐시를 비우는 기능도 있지만, 중학생 수업에서는 우선 “현재 연결 상태 읽기”에 집중하는 것이 좋습니다.',
    example: 'ipconfig\nipconfig /all\nipconfig /flushdns'
  },
  'ping': {
    title: 'ping',
    subtitle: 'Packet Internet Groper / 네트워크의 노크 소리',
    short: '목적지 서버에 작은 신호를 보내고 답장이 돌아오는지 확인합니다. 응답 시간으로 네트워크 상태를 가늠합니다.',
    long: 'ping은 네트워크에서 “거기까지 길이 열려 있나요?”라고 가볍게 두드리는 도구입니다. 응답 시간이 짧으면 비교적 빠르게 왕복한 것이고, 손실이 많으면 연결이 불안정할 수 있습니다. 다만 ping 응답이 없다고 해서 항상 서버가 죽은 것은 아닙니다. 보안 설정상 ping 요청을 일부러 무시하는 서버도 있기 때문입니다.',
    example: 'ping example.com\nping 8.8.8.8'
  },
  'nslookup': {
    title: 'nslookup',
    subtitle: 'Name Server Lookup',
    short: 'DNS 서버에게 도메인 이름이 어떤 IP 주소와 연결되는지 물어보는 명령어입니다.',
    long: 'nslookup은 “사람이 읽는 이름”과 “컴퓨터가 찾아가는 주소” 사이의 번역 결과를 보여줍니다. 예를 들어 example.com을 입력하면 DNS는 그 이름에 대응하는 IP 주소를 알려줍니다. 보안 관점에서는 가짜 사이트, 이상한 도메인, DNS 문제를 이해하는 출발점이 됩니다.',
    example: 'nslookup example.com\nnslookup naver.com'
  },
  'tracert': {
    title: 'tracert',
    subtitle: 'Trace Route',
    short: '패킷이 목적지까지 가는 동안 지나가는 중간 라우터와 각 구간의 지연 시간을 보여줍니다.',
    long: 'tracert는 패킷의 여행 일지를 펼쳐보는 명령어입니다. 내 컴퓨터에서 서버까지 데이터가 바로 가는 것처럼 보여도 실제로는 공유기, 통신사 장비, 여러 라우터를 거쳐 이동합니다. Windows에서는 tracert, macOS와 Linux에서는 traceroute라는 이름으로 많이 사용합니다.',
    example: 'tracert example.com\ntraceroute example.com  # macOS/Linux'
  },
  'HTTP': {
    title: 'HTTP', subtitle: 'HyperText Transfer Protocol',
    short: '웹 브라우저와 서버가 웹페이지를 주고받기 위한 기본 약속입니다. 암호화가 기본으로 들어 있지 않습니다.',
    long: 'HTTP는 웹의 기본 대화 규칙입니다. 브라우저가 “이 페이지를 주세요”라고 요청하면 서버가 HTML, CSS, 이미지 같은 자료를 응답합니다. 하지만 HTTP만 사용하면 통신 내용이 암호화되지 않아 같은 네트워크나 중간 경로에서 내용이 노출될 위험이 있습니다. 그래서 로그인, 결제, 개인정보 입력 페이지에서는 HTTPS를 사용해야 합니다.',
    example: 'http://example.com\n기본 포트: 80\n보안 관점: 중요한 정보 입력에는 부적절'
  },
  'HTTPS': {
    title: 'HTTPS', subtitle: 'HTTP Secure',
    short: 'HTTP에 암호화를 더한 방식입니다. 통신 내용을 중간에서 쉽게 훔쳐보거나 바꾸지 못하게 보호합니다.',
    long: 'HTTPS는 브라우저와 서버 사이의 통신을 암호화합니다. 비밀번호, 쿠키, 개인정보가 이동할 때 중간에서 그대로 읽히는 위험을 줄여줍니다. 다만 HTTPS는 “통신 경로가 암호화되었다”는 뜻이지 “그 사이트가 반드시 착한 사이트다”라는 뜻은 아닙니다. 피싱 사이트도 HTTPS 인증서를 사용할 수 있으므로 중심 도메인을 함께 확인해야 합니다.',
    example: 'https://accounts.google.com\n기본 포트: 443\n주의: 자물쇠 = 공식 사이트 보증이 아님'
  },
  'TCP': {
    title: 'TCP', subtitle: 'Transmission Control Protocol',
    short: '데이터가 빠지지 않고 순서대로 도착하도록 확인하는 안정성 중심의 전송 규칙입니다.',
    long: 'TCP는 데이터를 여러 조각으로 나누어 보내고, 조각이 빠졌거나 순서가 틀리면 다시 맞추도록 도와줍니다. 웹페이지, 로그인, 파일 다운로드처럼 내용이 정확해야 하는 통신에 적합합니다. 속도만 보면 UDP보다 무겁지만, 안정적으로 도착했는지 확인한다는 장점이 있습니다.',
    example: '웹 접속, 이메일, 파일 다운로드\n특징: 연결 확인, 순서 보장, 재전송'
  },
  'UDP': {
    title: 'UDP', subtitle: 'User Datagram Protocol',
    short: '확인 절차를 줄여 빠르게 보내는 속도 중심의 전송 규칙입니다.',
    long: 'UDP는 TCP처럼 하나하나 도착 확인을 꼼꼼히 하지 않습니다. 그래서 빠르고 가볍습니다. 실시간 게임, 영상, 음성 통화처럼 약간의 손실보다 즉각적인 반응이 더 중요한 상황에서 자주 사용됩니다. 대신 순서 보장이나 재전송은 약하기 때문에 중요한 파일 전송에는 보통 TCP가 더 적합합니다.',
    example: '실시간 게임, 음성 통화, 영상 스트리밍\n특징: 빠름, 가벼움, 도착 보장 약함'
  },
  'DNS': {
    title: 'DNS', subtitle: 'Domain Name System',
    short: '도메인 이름을 IP 주소로 바꿔주는 인터넷의 이름표 번역 시스템입니다.',
    long: '사람은 숫자 주소보다 naver.com, google.com 같은 이름을 더 잘 기억합니다. 하지만 컴퓨터는 실제 통신에서 IP 주소를 사용합니다. DNS는 두 세계를 연결하는 번역기입니다. 보안에서는 사용자가 진짜 사이트로 가고 있는지, 이상한 주소로 유도되고 있지 않은지 이해하는 데 중요합니다.',
    example: 'example.com → 93.184.216.34'
  },
  'IPv4 주소': {
    title: 'IPv4 주소', subtitle: '네트워크 안의 장치 주소',
    short: '네트워크에서 내 컴퓨터를 구분하기 위한 주소입니다. 집 주소처럼 목적지를 찾는 데 쓰입니다.',
    long: 'IPv4 주소는 192.168.0.24처럼 네 개의 숫자 묶음으로 표현됩니다. 집이나 학교 공유기 안에서는 192.168.x.x 같은 사설 IP를 많이 봅니다. 같은 교실 안에서 학생마다 자리가 다르듯, 같은 네트워크 안의 장치도 서로 다른 주소를 가져야 합니다.',
    example: '192.168.0.24\n10.0.0.15\n172.16.1.8'
  },
  '기본 게이트웨이': {
    title: '기본 게이트웨이', subtitle: '네트워크 밖으로 나가는 첫 번째 문',
    short: '내 컴퓨터가 외부 인터넷으로 나갈 때 먼저 찾아가는 장치입니다. 보통 공유기 주소입니다.',
    long: '내 컴퓨터가 같은 Wi-Fi 안의 장치와 통신할 때는 가까운 곳에서 해결할 수 있습니다. 하지만 외부 웹사이트로 가려면 네트워크 밖으로 나가는 문이 필요합니다. 그 첫 번째 문이 기본 게이트웨이입니다. 집이나 학교에서는 대부분 공유기가 이 역할을 합니다.',
    example: '기본 게이트웨이: 192.168.0.1'
  },
  'TTL': {
    title: 'TTL', subtitle: 'Time To Live',
    short: '패킷이 네트워크 안에서 무한히 떠돌지 않도록 제한하는 수명 값입니다.',
    long: '인터넷은 복잡한 길로 연결되어 있어서 잘못된 경로가 생기면 패킷이 계속 빙글빙글 돌 수도 있습니다. TTL은 패킷에 붙은 제한 시간표 같은 값입니다. 라우터를 하나 지날 때마다 줄어들고, 0이 되면 버려집니다.',
    example: 'TTL=56'
  },
  '홉': {
    title: '홉 Hop', subtitle: '패킷이 거쳐 간 한 단계',
    short: '패킷이 목적지까지 가는 동안 라우터 하나를 지날 때마다 한 홉이라고 볼 수 있습니다.',
    long: 'tracert 결과의 1번, 2번, 3번 줄은 패킷이 목적지까지 이동하며 지나간 단계입니다. 각 단계는 보통 라우터나 네트워크 장비를 의미합니다. 홉이 많다고 무조건 나쁜 것은 아니지만, 어느 구간에서 시간이 오래 걸리는지 관찰할 수 있습니다.',
    example: '1홉: 공유기\n2홉: 통신사 장비\n3홉 이후: 인터넷 경로'
  },
  '지연 시간': {
    title: '지연 시간 Latency', subtitle: '왕복에 걸린 시간',
    short: '패킷이 목적지까지 갔다가 돌아오는 데 걸린 시간입니다. 보통 ms 단위로 표시됩니다.',
    long: '온라인 게임에서 핑이 높다고 말할 때의 그 핑이 바로 지연 시간과 관련 있습니다. 지연 시간이 낮으면 반응이 빠르고, 높으면 버튼을 눌렀는데 늦게 반응하는 느낌이 생길 수 있습니다.',
    example: '시간=28ms'
  },
  '쿠키': {
    title: '쿠키 Cookie', subtitle: '브라우저에 저장되는 작은 정보',
    short: '웹사이트가 브라우저에 저장해두는 작은 정보입니다. 로그인 상태, 장바구니, 설정값 등에 사용됩니다.',
    long: '쿠키는 웹사이트가 브라우저에 남겨두는 작은 메모입니다. “이 사용자가 방금 로그인했다”, “장바구니에 이 물건이 있다”, “다크 모드를 사용한다” 같은 정보를 기억하는 데 쓰입니다. 하지만 쿠키 안에 민감한 정보가 그대로 들어가거나, 세션 ID가 노출되면 보안 문제가 생길 수 있습니다.',
    example: 'Set-Cookie: session_id=abc123; Secure; HttpOnly'
  },
  '세션': {
    title: '세션 Session', subtitle: '서버가 기억하는 로그인 상태',
    short: '서버가 현재 사용자의 로그인 상태를 기억하기 위한 정보입니다.',
    long: 'HTTP는 기본적으로 요청 하나하나를 따로 보는 성격이 있습니다. 그래서 서버는 “이 요청이 방금 로그인한 같은 사용자에게서 온 것”인지 기억할 방법이 필요합니다. 세션은 서버 쪽에서 사용자의 상태를 기억하는 방식이고, 브라우저는 보통 세션 ID라는 임시 출입증을 쿠키로 들고 다닙니다.',
    example: '로그인 성공 → 서버가 세션 생성 → 브라우저가 세션 ID 쿠키 보관'
  },
  '세션 ID': {
    title: '세션 ID Session ID', subtitle: '로그인 상태를 가리키는 임시 출입증',
    short: '서버가 사용자의 세션을 찾기 위해 발급하는 임시 식별자입니다.',
    long: '세션 ID는 서버가 만든 로그인 상태를 찾아가기 위한 번호표입니다. 누군가 내 세션 ID를 훔치면, 비밀번호를 몰라도 내 로그인 상태처럼 행동할 위험이 있습니다. 그래서 HTTPS, HttpOnly, Secure 같은 설정과 공용 PC 로그아웃 습관이 중요합니다.',
    example: 'session_id=7f3a9c...'
  },
  '로그아웃': {
    title: '로그아웃 Logout', subtitle: '로그인 상태 끝내기',
    short: '서버와 브라우저에 남은 로그인 상태를 끝내는 행동입니다.',
    long: '공용 PC나 친구 기기에서 로그인한 뒤 창만 닫으면 세션이 남아 있을 수 있습니다. 로그아웃은 서버에게 “이 세션을 끝내 주세요”라고 알리는 행동입니다. 중요한 계정일수록 사용 후 로그아웃하고, 저장된 기기 목록도 확인하는 습관이 필요합니다.',
    example: '공용 PC 사용 후: 로그아웃 → 브라우저 종료 → 저장된 비밀번호 확인'
  },
  'MFA': {
    title: 'MFA', subtitle: 'Multi-Factor Authentication',
    short: '비밀번호 외에 다른 인증 요소를 추가해 계정을 보호하는 방식입니다.',
    long: 'MFA는 여러 종류의 증거를 조합해 사용자가 진짜인지 확인합니다. 예를 들어 비밀번호는 “내가 아는 것”, 휴대폰 OTP는 “내가 가진 것”, 지문은 “내 몸의 특징”입니다. 공격자가 비밀번호를 알아도 두 번째 증거가 없으면 로그인을 막을 수 있습니다.',
    example: '비밀번호 + OTP 앱\n비밀번호 + 보안키\n비밀번호 + 지문'
  },
  '2단계 인증': {
    title: '2단계 인증', subtitle: '비밀번호 이후 한 번 더 확인',
    short: '비밀번호가 맞아도 한 번 더 본인 확인을 요구하는 계정 보호 기능입니다.',
    long: '2단계 인증은 계정 보안에서 학생들이 가장 먼저 적용하기 좋은 방어 방법입니다. 비밀번호가 피싱이나 유출로 알려져도, 휴대폰 알림, OTP 코드, 보안키 같은 추가 확인이 없으면 공격자가 로그인하기 어렵습니다.',
    example: '1단계: 비밀번호\n2단계: OTP 코드 또는 휴대폰 승인'
  },
  '지식 요소': {
    title: '지식 요소 Knowledge Factor', subtitle: '내가 아는 것',
    short: '비밀번호나 PIN처럼 사용자가 기억하고 있는 인증 정보입니다.',
    long: '지식 요소는 가장 흔한 인증 방식입니다. 하지만 피싱, 유출, 추측, 재사용 때문에 단독으로는 약해질 수 있습니다. 그래서 중요한 계정에서는 소유 요소나 생체 요소를 함께 사용하는 것이 좋습니다.',
    example: '비밀번호, PIN, 보안 질문'
  },
  '소유 요소': {
    title: '소유 요소 Possession Factor', subtitle: '내가 가진 것',
    short: '휴대폰, OTP 앱, 보안키처럼 실제로 가지고 있어야 하는 인증 수단입니다.',
    long: '공격자가 비밀번호를 알더라도 내 휴대폰이나 보안키까지 가지고 있지 않다면 로그인을 막을 수 있습니다. 그래서 소유 요소는 계정 탈취를 막는 데 큰 도움이 됩니다.',
    example: 'OTP 앱, 인증 알림, 보안키, 학생증 카드'
  },
  '생체 요소': {
    title: '생체 요소 Biometric Factor', subtitle: '내 몸의 특징',
    short: '지문, 얼굴, 홍채처럼 몸의 특징을 이용하는 인증 방식입니다.',
    long: '생체 인증은 편리하지만, 모든 상황에서 완벽한 것은 아닙니다. 기기 안에서 안전하게 처리되어야 하며, 중요한 계정은 생체 인증만 믿기보다 기기 잠금과 2단계 인증을 함께 사용하는 것이 좋습니다.',
    example: '지문 인식, 얼굴 인식'
  },
  '앱 권한': {
    title: '앱 권한 Permission', subtitle: '앱이 접근할 수 있는 기능과 정보',
    short: '앱이 카메라, 마이크, 위치, 연락처 같은 기능에 접근하도록 허락하는 설정입니다.',
    long: '앱 권한은 스마트폰 보안에서 매우 현실적인 주제입니다. 지도 앱의 위치 권한은 자연스럽지만, 손전등 앱이 연락처와 마이크 권한을 요구한다면 의심해야 합니다. 권한을 허용할 때는 “이 앱의 기능에 정말 필요한가?”를 기준으로 판단합니다.',
    example: '카메라, 마이크, 위치, 연락처, 사진, 알림 권한'
  },
  '최소 권한': {
    title: '최소 권한 Least Privilege', subtitle: '필요한 만큼만 허용하기',
    short: '사용자나 앱이 자기 역할에 꼭 필요한 권한만 갖게 하는 보안 원칙입니다.',
    long: '최소 권한 원칙은 사고가 나도 피해 범위를 줄이는 방법입니다. 예를 들어 사진 편집 앱은 사진 접근이 필요할 수 있지만, 연락처 전체 접근은 필요하지 않을 수 있습니다. 권한을 적게 줄수록 문제가 생겼을 때 훔쳐갈 수 있는 정보도 줄어듭니다.',
    example: '위치: 앱 사용 중에만 허용\n마이크: 필요할 때만 허용\n연락처: 불필요하면 거부'
  }
};
function normalizeTerm(text){
  if(!text) return '';
  const cleaned = text.trim().replace(/[\n\t]+/g,' ').replace(/["'“”‘’.,:;()\[\]{}]/g,'');
  const keys = Object.keys(termData).sort((a,b)=>b.length-a.length);
  const lower = cleaned.toLowerCase();
  for(const key of keys){
    if(lower === key.toLowerCase()) return key;
  }
  for(const key of keys){
    if(lower.includes(key.toLowerCase())) return key;
  }
  return '';
}
let activeTermKey = '';
function showTermPopover(key, rect){
  const data = termData[key], pop = $('#termPopover');
  if(!data || !pop) return;
  activeTermKey = key;
  $('#termPopoverTitle').textContent = data.title;
  $('#termPopoverText').textContent = data.short;
  const top = Math.max(88, rect.top + scrollY - 12);
  const left = Math.min(innerWidth - 320, Math.max(18, rect.left + scrollX + rect.width / 2 - 150));
  pop.style.left = left + 'px';
  pop.style.top = top + 'px';
  pop.classList.add('show');
  pop.setAttribute('aria-hidden','false');
}
function hideTermPopover(){
  const pop = $('#termPopover');
  if(pop){ pop.classList.remove('show'); pop.setAttribute('aria-hidden','true'); }
}
function openTermModal(key){
  const data = termData[key];
  if(!data) return;
  $('#modalContent').innerHTML = `<div class="term-modal-kicker">NETWORK TERM</div><h3>${data.title}</h3><p class="term-subtitle">${data.subtitle}</p><p>${data.long}</p><code>${data.example}</code><div class="callout"><strong>수업 포인트</strong><p>학생에게 “이 명령어로 무엇을 공격할 수 있나?”보다 “이 출력에서 무엇을 읽을 수 있나?”를 묻게 하면 보안 수업의 방향이 안전해집니다.</p></div>`;
  $('#modal').classList.add('open');
  $('#modal').setAttribute('aria-hidden','false');
  hideTermPopover();
}
document.addEventListener('mouseup', () => {
  setTimeout(() => {
    const sel = getSelection();
    const text = sel ? sel.toString() : '';
    const key = normalizeTerm(text);
    if(!key || !sel.rangeCount){ hideTermPopover(); return; }
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    if(rect.width === 0 && rect.height === 0){ hideTermPopover(); return; }
    showTermPopover(key, rect);
  }, 20);
});
document.addEventListener('mousedown', e => {
  if(!e.target.closest('#termPopover') && !e.target.closest('[data-term-chip]') && !e.target.closest('[data-term-card]')) hideTermPopover();
});
$('#termPopover')?.addEventListener('click', () => openTermModal(activeTermKey));
$$('[data-term-chip]').forEach(chip => chip.addEventListener('click', () => {
  const rect = chip.getBoundingClientRect();
  showTermPopover(chip.dataset.termChip, rect);
}));
$$('[data-term-card]').forEach(card => card.addEventListener('click', () => openTermModal(card.dataset.termCard)));

/* ===== v4: URL literacy, HTTPS nuance, log analysis, security checklist, final mission ===== */
const urlCases = [
  {
    label:'https://accounts.google.com/login',
    protocol:'https', host:'accounts.google.com', domain:'google.com', path:'/login', verdict:'공식 Google 계정 도메인의 하위 도메인입니다. 그래도 로그인 전에는 주소 전체를 확인합니다.'
  },
  {
    label:'https://google.com.security-login-check.site',
    protocol:'https', host:'google.com.security-login-check.site', domain:'security-login-check.site', path:'/', verdict:'앞에 google.com이 보이지만 실제 중심 도메인은 security-login-check.site입니다. 매우 의심해야 합니다.'
  },
  {
    label:'http://school-login-free-check.example',
    protocol:'http', host:'school-login-free-check.example', domain:'school-login-free-check.example', path:'/', verdict:'HTTP이고, free/check/login 같은 미끼 단어가 섞여 있습니다. 공식 안내 없이 로그인하면 안 됩니다.'
  },
  {
    label:'https://www.youtube.com/watch?v=security',
    protocol:'https', host:'www.youtube.com', domain:'youtube.com', path:'/watch?v=security', verdict:'중심 도메인은 youtube.com입니다. 그래도 댓글/설명란의 외부 링크는 따로 확인해야 합니다.'
  }
];
function renderUrlCases(){
  const box=$('#urlSamples'); if(!box) return;
  box.innerHTML='';
  urlCases.forEach((u,i)=>{
    const btn=document.createElement('button'); btn.textContent=u.label;
    btn.addEventListener('click',()=>renderUrlBreakdown(i));
    box.appendChild(btn);
  });
  renderUrlBreakdown(0);
}
function renderUrlBreakdown(i){
  const u=urlCases[i], box=$('#urlBreakdown'); if(!box) return;
  $$('#urlSamples button').forEach((b,idx)=>b.classList.toggle('active',idx===i));
  box.innerHTML=`
    <div class="url-part"><b>프로토콜</b><span>${u.protocol}</span><p>${u.protocol==='https'?'통신 암호화가 켜져 있습니다.':'암호화되지 않은 HTTP입니다. 로그인과 개인정보 입력에 부적절합니다.'}</p></div>
    <div class="url-part"><b>호스트 이름</b><span>${u.host}</span><p>브라우저가 실제로 접속하려는 서버 이름입니다.</p></div>
    <div class="url-part"><b>중심 도메인</b><span>${u.domain}</span><p>피싱 판별에서 가장 중요하게 봐야 하는 부분입니다.</p></div>
    <div class="url-part"><b>경로</b><span>${u.path}</span><p>사이트 안에서 어떤 페이지를 요청하는지 나타냅니다.</p></div>
    <div class="callout ${u.verdict.includes('의심')?'warn':'safe'}"><strong>판단</strong><p>${u.verdict}</p></div>`;
}
renderUrlCases();

const logCases=[
  {
    logs:`[2026-07-08 10:15:22] LOGIN SUCCESS user=student01 ip=192.168.0.12\n[2026-07-08 10:16:03] LOGIN FAILED  user=admin ip=203.0.113.8\n[2026-07-08 10:16:05] LOGIN FAILED  user=admin ip=203.0.113.8\n[2026-07-08 10:16:07] LOGIN FAILED  user=admin ip=203.0.113.8\n[2026-07-08 10:16:09] LOGIN FAILED  user=admin ip=203.0.113.8`,
    answer:'짧은 시간에 admin 로그인 실패가 반복된다',
    choices:['정상적인 학생 로그인 1회가 있다','짧은 시간에 admin 로그인 실패가 반복된다','IP 주소가 숫자로 되어 있다','시간이 초 단위로 표시된다'],
    explain:'관리자 계정에 대해 짧은 시간 동안 반복 실패가 발생하면 무차별 대입이나 자동화 시도를 의심할 수 있습니다.'
  },
  {
    logs:`[2026-07-08 21:03:11] LOGIN SUCCESS user=studentA ip=192.168.0.21 device=Chrome-Windows\n[2026-07-08 21:05:44] PASSWORD CHANGE user=studentA ip=198.51.100.77 device=Unknown\n[2026-07-08 21:06:02] NEW DEVICE ADDED user=studentA ip=198.51.100.77 device=Unknown`,
    answer:'낯선 IP와 새 기기에서 비밀번호 변경이 발생했다',
    choices:['같은 사용자가 로그인했다','낯선 IP와 새 기기에서 비밀번호 변경이 발생했다','Chrome이 사용되었다','로그가 세 줄이다'],
    explain:'비밀번호 변경과 새 기기 등록은 계정 장악의 강한 신호입니다. 즉시 비밀번호 변경, 세션 로그아웃, 2단계 인증 설정이 필요합니다.'
  }
];
let logIndex=0;
function renderLogCase(){
  const c=logCases[logIndex], con=$('#logConsole'), choices=$('#logChoices'), result=$('#logResult');
  if(!con||!choices) return;
  con.textContent=c.logs; choices.innerHTML=''; if(result) result.textContent='';
  c.choices.forEach(choice=>{
    const btn=document.createElement('button'); btn.textContent=choice;
    btn.addEventListener('click',()=>{
      $$('#logChoices button').forEach(b=>b.classList.remove('correct','wrong'));
      if(choice===c.answer){btn.classList.add('correct'); result.textContent='정답입니다. '+c.explain;}
      else{btn.classList.add('wrong'); result.textContent='다시 보세요. 로그에서 반복, 낯선 위치, 권한 변경 같은 패턴을 찾는 것이 핵심입니다.';}
    });
    choices.appendChild(btn);
  });
}
$('#nextLogCase')?.addEventListener('click',()=>{logIndex=(logIndex+1)%logCases.length; renderLogCase();});
renderLogCase();

function updateSecurityChecklist(){
  const checks=$$('#securityChecklist input'); if(!checks.length) return;
  const done=checks.filter(c=>c.checked).length;
  const bar=$('#checkProgressBar'), text=$('#checkProgressText');
  if(bar) bar.style.width=(done/checks.length*100)+'%';
  if(text) text.textContent=`${done} / ${checks.length} 완료`;
}
$$('#securityChecklist input').forEach(ch=>ch.addEventListener('change',updateSecurityChecklist));
updateSecurityChecklist();

const missionItems=[
  {q:'Q1. 가장 가능성 높은 공격 흐름은?', options:['피싱 → 계정 탈취 → 피해 확산','정상 업데이트 → 로그인 성공','DNS 조회 → 인터넷 연결 확인'], answer:0},
  {q:'Q2. 피해가 커진 가장 큰 이유는?', options:['같은 비밀번호를 여러 서비스에서 재사용했다','브라우저를 사용했다','URL에 https가 없었다'], answer:0},
  {q:'Q3. 지금 가장 먼저 해야 할 대응은?', options:['비밀번호 변경, 다른 사이트 비밀번호도 변경, 2단계 인증 설정','친구에게 링크를 더 보내보기','컴퓨터를 끄고 아무것도 하지 않기'], answer:0}
];
function renderMission(){
  const box=$('#missionQuestions'); if(!box) return;
  box.innerHTML=missionItems.map((m,idx)=>`<div class="mission-question"><h3>${m.q}</h3>${m.options.map((o,i)=>`<label><input type="radio" name="mission${idx}" value="${i}"> ${o}</label>`).join('')}</div>`).join('');
}
$('#checkMission')?.addEventListener('click',()=>{
  let score=0;
  missionItems.forEach((m,idx)=>{ const picked=$(`input[name="mission${idx}"]:checked`); if(picked && Number(picked.value)===m.answer) score++; });
  const result=$('#missionResult');
  if(result) result.textContent = score===missionItems.length ? '완벽합니다. 피싱으로 시작된 계정 탈취와 비밀번호 재사용의 위험까지 정확히 분석했습니다.' : `${score}/${missionItems.length}개 정답입니다. 핵심 흐름은 피싱 → 계정 탈취 → 비밀번호 재사용으로 피해 확산입니다.`;
});
renderMission();


/* ===== v4.2: cookie/session, MFA, permission mini activity ===== */
$$('[data-permission]').forEach(btn => btn.addEventListener('click', () => {
  const ok = btn.dataset.permission === 'correct';
  $$('#permissionChoices button').forEach(b => b.classList.remove('correct','wrong'));
  btn.classList.add(ok ? 'correct' : 'wrong');
  const result = $('#permissionResult');
  if(result){
    result.textContent = ok
      ? '정답입니다. 손전등 기능에 연락처·위치·마이크 권한은 보통 필요하지 않습니다. 기능에 비해 과한 권한 요청은 의심해야 합니다.'
      : '다시 생각해보세요. 권한은 “앱 기능에 꼭 필요한가?”를 기준으로 판단하는 것이 좋습니다.';
  }
}));


/* ===== v4.4: End-of-class event ===== */
const agentTitles = [
  'PACKET GUARDIAN',
  'DNS DETECTIVE',
  'PHISHING HUNTER',
  'SESSION KEEPER',
  'ZERO-TRUST ROOKIE',
  'LOG ANALYST JR.'
];
function runConfetti(){
  const colors = ['#35e6ff','#61ffb4','#ffd166','#9b7bff','#ff6b8a'];
  for(let i=0;i<70;i++){
    const p=document.createElement('i');
    p.className='confetti-piece';
    p.style.left=Math.random()*100+'vw';
    p.style.background=colors[i%colors.length];
    p.style.animationDelay=(Math.random()*0.45)+'s';
    p.style.transform=`rotate(${Math.random()*180}deg)`;
    document.body.appendChild(p);
    setTimeout(()=>p.remove(),2400);
  }
}
function openClassEndEvent(){
  let shell=$('#classEndEvent');
  const title=agentTitles[Math.floor(Math.random()*agentTitles.length)];
  const completed=$$('#securityChecklist input:checked').length;
  const total=$$('#securityChecklist input').length || 7;
  if(!shell){
    shell=document.createElement('div');
    shell.id='classEndEvent';
    shell.className='end-event-shell';
    shell.innerHTML=`
      <div class="end-event-card" role="dialog" aria-modal="true" aria-label="수업 완료 이벤트">
        <button class="end-event-close" aria-label="닫기">×</button>
        <div class="agent-badge">SEC</div>
        <h2>MISSION <em>CLEAR</em></h2>
        <div class="agent-title" id="agentTitle">AGENT TITLE</div>
        <p class="lead">오늘의 보안 훈련을 완료했습니다. 이제부터 의심스러운 링크, 낯선 로그인, 과한 앱 권한을 그냥 넘기지 않는 보안 감각을 장착했습니다.</p>
        <pre class="agent-terminal" id="endTerminal"></pre>
        <div class="end-achievements">
          <article><b>Network Sense</b><span>IP, DNS, Packet, Protocol의 역할을 설명할 수 있음</span></article>
          <article><b>Threat Radar</b><span>피싱, 악성코드, 계정 탈취의 위험 신호를 구분함</span></article>
          <article><b>Defense Habit</b><span>2단계 인증, 권한 확인, 로그아웃 습관을 이해함</span></article>
        </div>
        <div class="end-actions">
          <button class="primary-mini" id="copyAgentCard">인증 문구 복사</button>
          <button class="ghost-mini" id="closeEndEvent">교재로 돌아가기</button>
        </div>
      </div>`;
    document.body.appendChild(shell);
    shell.querySelector('.end-event-close').addEventListener('click',()=>shell.classList.remove('open'));
    shell.querySelector('#closeEndEvent').addEventListener('click',()=>shell.classList.remove('open'));
    shell.addEventListener('click',e=>{ if(e.target===shell) shell.classList.remove('open'); });
    shell.querySelector('#copyAgentCard').addEventListener('click',async()=>{
      const msg='Security Week 01 Mission Clear: 나는 오늘 네트워크 보안의 기본 원리와 안전한 방어 습관을 배웠다.';
      try{ await navigator.clipboard.writeText(msg); shell.querySelector('#copyAgentCard').textContent='복사 완료'; }
      catch{ shell.querySelector('#copyAgentCard').textContent='복사 실패'; }
      setTimeout(()=>shell.querySelector('#copyAgentCard').textContent='인증 문구 복사',1300);
    });
  }
  $('#agentTitle',shell).textContent=`${title} · CLASS COMPLETE`;
  const term=`$ verify_student --safe-mode\n[OK] 타인 대상 공격: 0\n[OK] 방어 개념 학습: complete\n[OK] 보안 체크리스트: ${completed}/${total}\n[OK] 획득 배지: ${title}\n\n오늘의 로그:\n- 의심스러운 링크는 멈추고 확인한다.\n- 비밀번호는 재사용하지 않는다.\n- 2단계 인증은 켜둔다.\n- 보안의 첫 번째 실력은 멈출 줄 아는 것이다.\n\n> class_dismissed();`;
  $('#endTerminal',shell).textContent=term;
  shell.classList.add('open');
  runConfetti();
}
$('#classEndBtn')?.addEventListener('click',openClassEndEvent);
